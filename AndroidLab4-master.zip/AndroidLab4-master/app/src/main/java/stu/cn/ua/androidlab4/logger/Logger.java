package stu.cn.ua.androidlab4.logger;

public interface Logger {

    void e(Throwable e);
}

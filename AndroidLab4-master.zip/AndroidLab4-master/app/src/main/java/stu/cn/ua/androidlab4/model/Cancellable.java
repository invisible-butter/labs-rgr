package stu.cn.ua.androidlab4.model;

public interface Cancellable {

    void cancel();
}
